def symbols(file):
    stats = [
            ("hp","\\uF810"),
            ("dmg","\\uF811"),
            ("attack_speed","\\uF812"),
            ("speed","\\uF813"),
            ("armor","\\uF814"),
            ("armor_toughness","\\uF815"),
            ("knock_resist","\\uF816"),
            ("mana_capacity","\\uF817"),
            ("mana_speed","\\uF818"),
            ("mana_cost","\\uF819"),
            ("souls_capacity","\\uF81a"),
            ("luck","\\uF81b"),
            ("curse","\\uF81c")
        ]
    for stat in stats:
        file.write("""
            {{
                "type": "bitmap",
                "file": "minecraft:symbols/stats/{}.png",
                "ascent": 8,
                "height": 8,
                "chars": ["{}"]
            }},""".format(stat[0], stat[1]))


    file.write("""
        {
            "type": "bitmap",
            "file": "minecraft:symbols/coin_meta.png",
            "ascent": 11,
            "height": 14,
            "chars": ["\\uF81d"]
        },""")

    file.write("""
        {
            "type": "bitmap",
            "file": "minecraft:symbols/coin_copper.png",
            "ascent": 8,
            "height": 9,
            "chars": ["\\uF81e"]
        },""")

    effects = [
            ("fire","\\uF830"),
            ("spore_poison","\\uF831"),
            ("freeze","\\uF832"),
            ("mage_armor","\\uF833")
        ]
    for effect in effects:
        file.write("""
            {{
                "type": "bitmap",
                "file": "minecraft:symbols/effects/{}.png",
                "ascent": -16,
                "height": 9,
                "chars": ["{}"]
            }},""".format(effect[0], effect[1]))


    file.write("""
        {
            "type": "bitmap",
            "file": "minecraft:symbols/trophy.png",
            "ascent": 8,
            "height": 9,
            "chars": ["\\uF3C6"]
        },
        {
            "type": "bitmap",
            "file": "minecraft:symbols/video_game.png",
            "ascent": 8,
            "height": 9,
            "chars": ["\\uF3AE"]
        },""")
